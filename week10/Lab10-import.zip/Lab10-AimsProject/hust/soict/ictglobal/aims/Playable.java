package hust.soict.ictglobal.aims;

public interface Playable {
	public void play();
}
